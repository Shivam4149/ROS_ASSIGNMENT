def start_node(
    print("This file has a syntax error")
